import React from 'react';
import { Heading } from '@chakra-ui/react';

export const EventsPage = () => {
  return <Heading>List of events</Heading>;
};
